import configparser
import json
import unittest
from rapid7interface import Rapid7Interface


class TestRapid7Interface(unittest.TestCase):

    def test_create_host_list(self):
        config = configparser.ConfigParser()
        config.read("../settings.ini")
        settings_dict = {}
        for section in config.sections():
            settings_dict[section] = {}
            for option in config.options(section):
                settings_dict[section][option] = config.get(section, option)
        rapid_interface = Rapid7Interface(settings_dict['RAPID7_SETTINGS'])
        test_dict = {
            'certificate-common-name-mismatch': {'title': 'X.509 Certificate Subject CN Does Not Match the Entity Name',
                                                 'description': 'The subject common name (CN) field in the X.509 '
                                                                'certificate',
                                                 'cves': ''}}
        rapid_interface._all_vulnerability_details_dict = test_dict
        with open('../test/data/hosts.json') as f:
            data = json.load(f)
        asset_pages = [data]
        hosts = rapid_interface.create_host_list(asset_pages)
        self.assertEqual(len(hosts), 1)
        host = hosts[0]
        self.assertEqual(host.get_ipaddress(), '10.4.18.155')
        self.assertEqual(len(host.get_vulnerabilities()), 1)
        vulnerability = host.get_vulnerabilities()[0]
        self.assertEqual(vulnerability.get_vuln_id(), 'certificate-common-name-mismatch')
        self.assertEqual(vulnerability.get_port(), 21)
        self.assertEqual(vulnerability.get_protocol(), 'tcp')
        self.assertEqual(vulnerability.get_title(), 'X.509 Certificate Subject CN Does Not Match the Entity Name')
        self.assertEqual(vulnerability.get_description(), 'The subject common name (CN) field in the X.509 certificate')
        self.assertEqual(vulnerability.get_cve_ids(), '')


if __name__ == '__main__':
    unittest.main()
