import os
import subprocess


class FMCInterface:
    """ This is interface to FMC to add Host Input CSV files. """

    def __init__(self, fmc_settings_dict, csv_settings_dict):
        self._fmc_ipaddress = fmc_settings_dict['fmc_ipaddress']
        self._debug = fmc_settings_dict['debug'].lower()
        self._target_directory = csv_settings_dict['csv_directory']

    def send_host_input_files(self):
        """ Processes each file present in the target directory and sends Host input information
        to the configured FMC instance.
        @ParamType List of CSV files. 
        @ReturnType boolean
        """
        for csv_file in os.listdir(self._target_directory):
            input_file = os.path.join(self._target_directory, csv_file)
            if self._debug == 'true':
                pipe = subprocess.run(["./HostInputApi/sf_host_input_agent.pl",
                                        "-server={}".format(self._fmc_ipaddress), "-level=3",
                                        "-plugininfo={}".format(input_file), "csv","-logfile=hostInput.log"],check=True,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            else:
                pipe = subprocess.run(["./HostInputApi/sf_host_input_agent.pl",
                                        "-server={}".format(self._fmc_ipaddress),
                                        "-level=0", "-plugininfo={}".format(input_file), "csv", "-logfile=hostInput.log"],check=True,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            