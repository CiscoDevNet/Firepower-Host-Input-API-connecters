import constants
import os

from log_initializer import get_logger


class HostInputCSVGenerator:

    def __init__(self, settings_dict):
        self._settings_dict = settings_dict
        self._logger = get_logger()

    def generate_host_input_csv_files(self, list_of_hosts):
        """ Generates a list of Host Input CSV files.Retrieves the target directory from the
        configuration file. If the directory exists, then remove it together with its contents
        and recreate the directory. If it does not exist, then create it.
        @ParamType list_of_hosts. A list of Host objects.
        @ReturnType list
        """
        target_directory = self._settings_dict['csv_directory']
        self._logger.info('Creating Host Input CSV files.')
        with open(os.path.join(target_directory, 'host_input.csv'), 'w', newline='') as host_input_csv_file:
            host_input_csv_file.write(constants.RAPID7_SET_SOURCE_HEADER)
            for host in list_of_hosts:
                if host.get_vulnerabilities():
                    rows = self.generate_host_input_apis(host)
                    for row in rows:
                        host_input_csv_file.write(row)
                else:
                    self._logger.info('Host {} did not contain any vulnerabilities.'.format(
                        host.get_ipaddress())
                    )
                    continue
            host_input_csv_file.write(constants.RAPID7_SCAN_FLUSH_FOOTER)
            self._logger.info('Host Input CSVs created.')

    def generate_host_input_apis(self, host):
        """ Generates Host Input API rows for each Host object. """
        host_input_rows = []
        ip_address = host.get_ipaddress()
        host_input_rows.append('{}, {}\n'.format(constants.RAPID7_ADD_HOST_CMD, ip_address))
        for vuln in host.get_vulnerabilities():
            vuln_id = vuln.get_hashed_numeric_vuln_id()
            port = vuln.get_port()
            protocol = vuln.get_protocol()
            title = vuln.get_title()
            description = vuln.get_description().replace('\n', '').replace('"', '')
            cve = vuln.get_cve_ids()
            bugtrac_id = vuln.get_bugtraq_ids()
            host_input_rows.append(
                "{}, {}, \"{}\", {}, {}, {}, \"{}\", \"{}\", \"{}: {}\", \"{}: {}\"\n".format(
                    constants.RAPID7_ADD_SCAN_RESULT_CMD, ip_address, constants.RAPID7_SOURCE_NAME,
                    vuln_id, port, protocol, title, description, constants.RAPID7_CVE_KEY_LABEL,
                    cve, constants.RAPID7_BUGTRAQ_KEY_LABEL, bugtrac_id))
        return host_input_rows
