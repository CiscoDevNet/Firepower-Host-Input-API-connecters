import logging
import os
import sys

from fmc_interface import FMCInterface
from host_input_csv_generator import HostInputCSVGenerator
from log_initializer import get_logger
from rapid7interface import Rapid7Interface


class HostInputConnector:

    def __init__(self, settings_dict):
        self._settings_dict = settings_dict
        self._logger = get_logger()
        """@AttributeType Rapid7Interface"""
        self._rapid_interface = None
        """@AttributeType FMCInterface"""
        self._fmc_interface = None
        """ @AttributeType HostInputCSVGenerator """
        self._host_input_csv_generator = None

    def get_all_hosts_from_rapid7(self):
        """ Invokes a rapid7interface instance and collects data and returns a list of all Host objects
        associated with the configured Rapid 7 API key.
        """
        self._rapid_interface = Rapid7Interface(self._settings_dict['RAPID7_SETTINGS'])
        if self._rapid_interface.check_connectivity():
            self._logger.info('Retrieving Asset pages from Rapid 7.')
            print('Retrieving Asset pages from Rapid 7.')
            pages, updated_last_scan_read = self._rapid_interface.get_asset_pages()
            self._logger.info('Asset pages received from Rapid 7.')
            print('Asset pages received from Rapid 7.')
            self._logger.info('Creating list of Hosts and associated vulnerabilities.')
            hosts = self._rapid_interface.create_host_list(pages)
            self._logger.info('List of Hosts and associated vulnerabilities generated.')
            print('List of Hosts and associated vulnerabilities generated.')
            self._logger.info('A total of {} hosts were processed.'.format(len(hosts)))
            return hosts, updated_last_scan_read
        else:
            print('Unable to establish connectivity to the Rapid 7 API.')
            sys.exit(1)

    def get_recently_scanned_hosts_from_rapid7(self):
        """ Invokes a rapid7interface instance and collects data and returns a list of Host objects
        whose last scan ended after the configured 'last_scan_read' key.
        """
        self._rapid_interface = Rapid7Interface(self._settings_dict['RAPID7_SETTINGS'])
        if self._rapid_interface.check_connectivity():
            last_scan_read = self._settings_dict['RAPID7_SETTINGS']['last_scan_read']
            self._logger.info('Retrieving Asset pages from Rapid 7 for assets scanned after {}.'.format(last_scan_read))
            print('Retrieving Asset pages from Rapid 7 for assets scanned after {}.'.format(last_scan_read))
            pages, updated_last_scan_read = self._rapid_interface.get_asset_pages(last_scan_read)
            self._logger.info('Asset pages received from Rapid 7 for assets scanned after {}.'.format(last_scan_read))
            print('Asset pages received from Rapid 7 for assets scanned after {}.'.format(last_scan_read))
            self._logger.info('Creating list of Hosts and associated vulnerabilities for assets scanned after {}.'
                              .format(last_scan_read))
            hosts = self._rapid_interface.create_host_list(pages)
            self._logger.info('List of Hosts and associated vulnerabilities generated for assets scanned after {}.'
                              .format(last_scan_read))
            print('List of Hosts and associated vulnerabilities generated for assets scanned after {}.'.format(
                last_scan_read))
            self._logger.info('A total of {} hosts were processed.'.format(len(hosts)))
            return hosts, updated_last_scan_read
        else:
            print('Unable to establish connectivity to the Rapid 7 API.')
            sys.exit(1)

    def generate_host_input_csv_files(self, list_of_hosts):
        self._host_input_csv_generator = HostInputCSVGenerator(
            self._settings_dict['CSV_FILE_SETTINGS'])
        self._host_input_csv_generator.generate_host_input_csv_files(list_of_hosts)

    def send_host_input_csv_files_to_fmc(self):
        """Send the files prepared for import to FMC. """
        self._fmc_interface = FMCInterface(self._settings_dict['FMC_SETTINGS'],
                                           self._settings_dict['CSV_FILE_SETTINGS'])
        self._logger.info('Sending Host Input CSV files to FMC.')
        self._fmc_interface.send_host_input_files()
