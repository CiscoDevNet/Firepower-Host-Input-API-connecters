#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import configparser
import sys

from log_initializer import get_logger
from log_initializer import set_logger
from host_input_connector import HostInputConnector
from settings import Settings

version = '1.0'

if __name__ == "__main__":
    settings = Settings('./settings.ini')
    settings.validate_config_file()
    settings_dict = settings.create_config_map()
    set_logger(settings_dict['LOG_SETTINGS'])
    logger = get_logger()
    host_input_connector = HostInputConnector(settings_dict)
    logger.info('Host Input Connector ' + version + ' started.')
    print('Host Input Connector ' + version + ' started.')
    print('Application logfile is available at connector/application.log.')

    if settings_dict['RAPID7_SETTINGS']['last_scan_read'] == '0':
        list_of_hosts, updated_last_scan_read = host_input_connector.get_all_hosts_from_rapid7()
    else:
        list_of_hosts, updated_last_scan_read = host_input_connector.get_recently_scanned_hosts_from_rapid7()

    if list_of_hosts:
        host_input_connector.generate_host_input_csv_files(list_of_hosts)
        host_input_connector.send_host_input_csv_files_to_fmc()
        settings.update_config_file('RAPID7_SETTINGS', 'last_scan_read', updated_last_scan_read)
        logger.info("Host Input Connector finished.")
        print('Host Input Connector finished.')
    else:
        logger.debug('No hosts were returned from the Rapid 7 API.')
        sys.exit(0)
