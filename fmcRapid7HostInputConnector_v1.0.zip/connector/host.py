class Host:

    def __init__(self):
        self._ipaddress = None
        self._vulnerabilities = []

    def set_ipaddress(self, ip_address):
        self._ipaddress = ip_address

    def get_ipaddress(self):
        return self._ipaddress

    def set_vulnerabilities(self, vulnerability):
        self._vulnerabilities.append(vulnerability)

    def get_vulnerabilities(self):
        return self._vulnerabilities
