import configparser
import os
import sys
import shutil
import constants


class Settings:

    def __init__(self, path_to_config):
        self.config = configparser.ConfigParser()
        self.config_file_path = path_to_config
        self.config.read(path_to_config)

    def create_config_map(self):
        config_map = {}
        for section in self.config.sections():
            config_map[section] = {}
            for option in self.config.options(section):
                config_map[section][option] = self.config.get(section, option)
        return config_map

    def is_file(self, file_path):
        return os.path.isfile(file_path)

    def is_file_readable(self, path_to_config):
        return os.access(path_to_config, os.R_OK)

    def is_file_writable(self, path_to_config):
        return os.access(path_to_config, os.W_OK)

    def update_config_file(self, section_header, key, updated_value):
        self.config.set(section_header, key, updated_value)
        with open(self.config_file_path, 'w') as configfile:
            self.config.write(configfile)

    def validate_config_file(self):
        if not self.is_file(self.config_file_path):
            print('Provided config file path does not exist or is not a file.')
            sys.exit(1)
        elif not self.is_file_readable(self.config_file_path):
            print('Provided config file is not readable.')
            sys.exit(1)
        elif not self.is_file_writable(self.config_file_path):
            print('Provided config file is not writable.')
            sys.exit(1)
        self.verify_config_sections()
        self.verify_critical_config_keys('RAPID7_SETTINGS', 'api_key')
        self.verify_critical_config_keys('FMC_SETTINGS', 'fmc_ipaddress')

        self.verify_host_input_path('CSV_FILE_SETTINGS', 'csv_directory')

    def verify_config_sections(self):
        for section in constants.EXPECTED_CONFIG_FILE_SECTIONS:
            if section not in self.config.sections():
                print('Config file is missing expected {} section.'.format(section))
                sys.exit(1)
        return True

    def verify_critical_config_keys(self, section, value):
        try:
            if self.config.get(section, value):
                return True
        except KeyError as e:
            raise SystemExit(e)
        except configparser.NoOptionError as e:
            raise SystemExit(e)
        else:
            print('Config file is missing {} value in {} Section.'.format(value, section))
            sys.exit(1)

    def verify_host_input_path(self, section, value):
        try:
            target_directory = self.config.get(section, value)
            if os.path.exists(target_directory) and os.path.isdir(target_directory):
                shutil.rmtree(target_directory)
                os.makedirs(target_directory)
            else:
                os.makedirs(target_directory)
        except:
            print('Cannot create directory {} value in {} Section.'.format(target_directory, section))
            sys.exit(1)
