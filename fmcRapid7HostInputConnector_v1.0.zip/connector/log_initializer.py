import logging
import configparser

logger = logging.getLogger(__name__)


def get_logger():
    return logger


def set_logger(settings_dict):
    config = configparser.ConfigParser()
    config.read(settings_dict)
    logger.setLevel(settings_dict['log_level'])
    file_handler = logging.FileHandler(settings_dict['log_file'], mode=settings_dict['mode'])
    file_handler.setLevel(settings_dict['file_handler_level'])
    format_ = logging.Formatter(settings_dict['log_format'])
    file_handler.setFormatter(format_)
    logger.addHandler(file_handler)
