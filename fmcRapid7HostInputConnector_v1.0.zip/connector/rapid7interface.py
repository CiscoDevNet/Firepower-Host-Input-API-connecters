import hashlib
import json
import requests

from datetime import datetime, timezone

from host import Host
from log_initializer import get_logger
from vulnerability import Vulnerability


class Rapid7Interface:

    def __init__(self, settings_dict):
        """ Note self._all_vulnerability_details_dict is a master map of
        'vuln_id' : {'title' : 'str', 'description' : 'str', 'cves' : 'str'}
        """
        self._settings_dict = settings_dict
        self._logger = get_logger()
        self._all_vulnerability_details_dict = {}

    def check_connectivity(self):
        """ Checks if the Rapid7 API is up.
        @ReturnType boolean """
        json_response = self.get_api_response('Health-Check', None, None)
        if json_response:
            return True
        else:
            self._logger.error('Unable to establish connectivity to the Rapid 7 API.')
            return False

    def create_host_list(self, asset_pages):
        """ Accepts a list of response pages. Processes each page in turn and returns a list of
        Host objects and their vulnerabilities. The vulnerabilities for each Host are represented
        as a list of Vulnerability objects. """
        hosts = []
        for page in asset_pages:
            self._logger.info("Processing Host and vulnerablity data for page {}.".format(
                page['metadata']['number']))
            for host_json_object in page['data']:
                hosts.append(self.create_host_object_from_json(host_json_object))
        return hosts

    def create_host_object_from_json(self, host_json_object):
        """ Injests a JSON object and returns a Host entity (i.e., object). """
        host = Host()
        self._logger.info('Creating Host {}'.format(host_json_object['ip']))
        host.set_ipaddress(host_json_object['ip'])
        vuln_types = [value for value in self._settings_dict['vuln_types'].split(',')]
        for vuln_type in vuln_types:
            if vuln_type in host_json_object and host_json_object[vuln_type]:
                for vulnerability in host_json_object[vuln_type]:
                    host.set_vulnerabilities(self.create_vulnerability_object_from_json(
                        vulnerability))
            else:
                self._logger.info('There are no {} vulnerabilities associated with {}.'.format(
                    vuln_type, host_json_object['ip']))
        self._logger.info('Created Host {} with {} vulnerabilities'.format(host.get_ipaddress(),
                                                                           len(host.get_vulnerabilities())))
        return host

    def create_vulnerability_object_from_json(self, vuln_json_object):
        """ Injests a JSON object and returns a Vulnerability entity (i.e., object). """
        vuln_object = Vulnerability()
        vuln_id = vuln_json_object['vulnerability_id']
        vuln_object.set_vuln_id(vuln_id)
        vuln_object.set_hashed_numeric_vuln_id(self.generate_numeric_hash(vuln_id))
        vuln_object.set_port(vuln_json_object['port'])
        vuln_object.set_protocol(vuln_json_object['protocol'])
        vuln_details = self.get_vulnerability_details(vuln_id)
        vuln_object.set_title(vuln_details['title'])
        vuln_object.set_description(vuln_details['description'])
        vuln_object.set_cve_ids(vuln_details['cves'])
        return vuln_object

    def generate_numeric_hash(self, vuln_id):
        return int(hashlib.sha256(vuln_id.encode('utf-8')).hexdigest(), 16) % 10**9

    def get_vulnerability_details(self, vuln_id):
        """ If the vulnerability details are already in the master map, retrieve them. Otherwise,
        issue an API call to the Rapid 7 Vulnerability endpoint and add the details to the
        master map to save API calls
        """
        if vuln_id in self._all_vulnerability_details_dict:
            return self._all_vulnerability_details_dict[vuln_id]
        else:
            vuln_details = self.get_vulnerability_details_from_api(vuln_id)
            self.add_vulnerability_details_to_map(vuln_id, vuln_details)
            return vuln_details

    def add_vulnerability_details_to_map(self, vuln_id, vuln_details):
        self._all_vulnerability_details_dict[vuln_id] = vuln_details

    def get_api_response(self, endpoint_alias, payload, params):
        base_rapid7_url, headers = self.get_base_rapid7_url_and_headers()
        response = None
        try:
            if endpoint_alias == 'Health-Check':
                url = base_rapid7_url + self._settings_dict['health_check_endpoint']
                response = requests.get(url, headers=headers)
            elif endpoint_alias == 'Asset':
                url = base_rapid7_url + self._settings_dict['asset_endpoint']
                response = requests.post(url, headers=headers, data=json.dumps(payload), params=params)
            elif endpoint_alias == 'Vulnerability':
                url = base_rapid7_url + self._settings_dict['vuln_endpoint']
                response = requests.post(url, headers=headers, data=json.dumps(payload))
            if response.status_code == 200:
                return response.json()
            else:
                response.raise_for_status()
        except requests.exceptions.HTTPError as http_error:
            self._logger.exception("Error Contacting Rapid7 {} API:".format(endpoint_alias))
            raise SystemExit(http_error)
        except requests.exceptions.ConnectionError as connection_error:
            self._logger.exception("Error Contacting Rapid7 {} API:".format(endpoint_alias))
            raise SystemExit(connection_error)
        except requests.exceptions.Timeout as timeout_error:
            self._logger.exception("Error Contacting Rapid7 {} API:".format(endpoint_alias))
            raise SystemExit(timeout_error)
        except requests.exceptions.RequestException as error:
            self._logger.exception("Error Contacting Rapid7 {} API:".format(endpoint_alias))
            raise SystemExit(error)

    def get_base_rapid7_url_and_headers(self):
        base_rapid7_url = self._settings_dict['rapid7_url']
        headers = {
            'X-Api-Key': self._settings_dict['api_key'],
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        return base_rapid7_url, headers

    def get_asset_pages(self, last_scan_read=None):
        """ Gets response pages from the Asset API endpoint. """
        total_resources, total_num_of_pages = self.get_paging_metadata_for_assets_api_response(last_scan_read)
        self._logger.info('There are {} total resources present across {} pages.'.format(
            total_resources, total_num_of_pages))
        if last_scan_read is None:
            payload = None
        else:
            payload = self.create_payload_for_asset_last_scan_end_filter(last_scan_read)
        pages = []
        updated_last_scan_read = datetime.now(timezone.utc).isoformat()
        for page in range(total_num_of_pages):
            response = self.get_api_response('Asset', payload, params={'page': page})
            self._logger.info('Received page number {} of {}.'.format(
                response['metadata']['number'], total_num_of_pages))
            pages.append(response)
        return pages, updated_last_scan_read

    def get_paging_metadata_for_assets_api_response(self, last_scan_read):
        """ Gets the total resources and number of pages from the Asset API. """
        if last_scan_read is None:
            payload = None
        else:
            payload = self.create_payload_for_asset_last_scan_end_filter(last_scan_read)
        first_page = self.get_api_response('Asset', payload, None)
        return first_page['metadata']['totalResources'], first_page['metadata']['totalPages']

    def create_payload_for_asset_last_scan_end_filter(self, last_scan_read):
        formatted_last_scan_end_date = "'{}'".format(last_scan_read)
        return {"asset": "last_scan_end > " + formatted_last_scan_end_date}

    def get_vulnerability_details_from_api(self, vulnerability_id):
        """ Connects to the Rapid7 Vulnerability API endpoint to retrieve vulnerability details,
        e.g., title, description, and associated CVE identifiers for Host vulnerabilities.
        There should only be a single JSON object in "data" list.
        """
        formatted_vuln_id = "'{}'".format(vulnerability_id)
        payload = {"vulnerability": "id=" + formatted_vuln_id}
        json_response = self.get_api_response('Vulnerability', payload, None)
        vuln_details = {'title': json_response['data'][0]['title'],
                        'description': json_response['data'][0]['description'],
                        'cves': json_response['data'][0]['cves']}
        return vuln_details
